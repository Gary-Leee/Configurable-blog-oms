import { defineConfig } from 'vite'
import path from 'path'
import createVitePlugins from "./config/vite/plugins"

function resovePath(paths: string) {
  return path.resolve(__dirname, paths)
}
// https://vitejs.dev/config/
export default defineConfig({
  plugins: createVitePlugins(),
  resolve: {
    alias: {
      '@': resovePath('./src'),
      '@config': resovePath('./config'),
      '@components': resovePath('./src/components'),
      '@utils': resovePath('./src/utils'),
      '@api': resovePath('./src/api'),
      '@assets': resovePath('./src/assets'),
    },
    extensions: ['.mjs', '.js', '.ts', '.jsx', '.tsx', '.json', '.vue'],
  },
})
