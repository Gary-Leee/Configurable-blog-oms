import { createRouter, createWebHistory } from 'vue-router'

const routes = [
    {
        path: '/',
        component: () => import('@/pages/login.vue')
    }
];
let history = createWebHistory();
export const router = createRouter({
    history,
    routes: routes
})