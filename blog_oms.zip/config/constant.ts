// 本地服务端口
export const VITE_PORT = 3001

// 包依赖分析
export const ANALYSIS = true

// 代码压缩
export const COMPRESSION = true

// serve
export const API_BASE_URL = process.env.NODE_ENV == 'development' ? '/api-biz' : '/open-api/api-biz'

//转化前中台接口
// export const API_TARGET_URL = 'http://10.38.123.37:9091'

//转化后
export const API_TARGET_URL = `http://116.62.60.32:3091${API_BASE_URL}`

// mock
export const MOCK_API_BASE_URL = '/mock/api'
export const MOCK_API_TARGET_URL = 'http://localhost:3000'

// 删除 console
export const VITE_DROP_CONSOLE = true
