import Components from 'unplugin-vue-components/vite'
import { VueUseComponentsResolver } from 'unplugin-vue-components/resolvers'

export const AutoRegisterComponents = () => {
  return Components({
    // 指定组件位置
    dirs: ['src/components'],
    // 组件的有效文件扩展名
    extensions: ['vue'],
    // 配置文件生成位置
    dts: 'src/components.d.ts',
    directoryAsNamespace: false,
    globalNamespaces: [],
    directives: true,
    // 搜索子目录
    deep: true,
    include: [/.vue$/, /.vue?vue/],
    exclude: [/[\/]node_modules[\/]/, /[\/].git[\/]/, /[\/].nuxt[\/]/],
    resolvers: [VueUseComponentsResolver()],
  })
}
