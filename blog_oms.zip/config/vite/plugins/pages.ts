import Pages from 'vite-plugin-pages'
import { resolve } from 'path'

export const ConfigPagesPlugin = () => {
  console.log('ConfigPagesPlugin')
  return Pages({
    dirs: [{ dir: './src/views', baseRoute: '' }],
    extensions: ['vue'],
    exclude: ['**/components/*.vue'],
    nuxtStyle: true,
  })
}
