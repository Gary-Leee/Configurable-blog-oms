import type { Plugin } from 'vite'
import vue from '@vitejs/plugin-vue'
import vueJsx from '@vitejs/plugin-vue-jsx'
// import { ConfigSvgIconsPlugin } from './svgIcons'
import { AutoRegisterComponents } from './component'
// import { ConfigCompressPlugin } from './compress'
// import { ConfigPagesPlugin } from './pages'
// import { ConfigVisualizerConfig } from './visualizer'
import { AutoImportDeps } from './autoImport'
// import { ConfigMockPlugin } from './mock'
// import { ConfigRestartPlugin } from './restart'
// import { ConfigLegacyPlugin } from './legacy'
// import viteCompression from 'vite-plugin-compression'
export default function createVitePlugins() {
  const vitePlugins: (Plugin | Plugin[])[] = [
    // vue支持
    vue(),
    // JSX支持
    vueJsx(),
    // 自动按需引入组件  自定义组件未生效
    AutoRegisterComponents(),
    // 自动生成路由 功能无效
    // ConfigPagesPlugin(),
    // 自动按需引入依赖
    AutoImportDeps(),
    // 开启.gz压缩
    // ConfigCompressPlugin(),
    // 监听配置文件改动重启
    // ConfigRestartPlugin(),
    // viteCompression({
    //   ext: '.gz',
    //   verbose: true,
    //   deleteOriginFile: false,
    // })
  ]

  return vitePlugins
}
