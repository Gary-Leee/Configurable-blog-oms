import legacy from '@vitejs/plugin-legacy'

export const ConfigLegacyPlugin = () => {
  return legacy({
    targets: ['defaults', 'ie >= 11', 'chrome 52'],
    additionalLegacyPolyfills: ['regenerator-runtime/runtime'],
  })
}
